s = "GeeksforGeeks"
rev = s[::-1]
print(rev)